jQuery(document).ready(function ($) {
    $('#dima-backup-form').on('submit', function (e) {
        e.preventDefault();

        const formData = $(this).serializeArray();
        const data = {};
        $.each(formData, function () {
            data[this.name] = this.value;
        });

        $('#progress-container').show();
        $('#backup-progress').val(0);
        $('#backup-status').text('در حال آغاز...');

        startBackup(data);
    });

    function startBackup(formData) {
        $.post(dimaAjax.ajaxurl, {
            action: 'dimabackup_start',
            security: dimaAjax.nonce,
            data: formData
        }).then(() => zipFiles(formData));
    }

    function zipFiles(formData) {
        $('#backup-status').text('در حال زیپ کردن فایل‌ها...');
        $.post(dimaAjax.ajaxurl, {
            action: 'dimabackup_zip',
            security: dimaAjax.nonce
        }).then(() => exportDB(formData));
    }

    function exportDB(formData) {
        $('#backup-status').text('در حال صادرات دیتابیس...');
        $.post(dimaAjax.ajaxurl, {
            action: 'dimabackup_export_db',
            security: dimaAjax.nonce
        }).then(() => generateImport(formData));
    }

    function generateImport(formData) {
        $('#backup-status').text('در حال ایجاد import.php...');
        $.post(dimaAjax.ajaxurl, {
            action: 'dimabackup_generate_import',
            security: dimaAjax.nonce
        }).then(() => {
            $('#backup-progress').val(100);
            $('#backup-status').text('✅ بک‌آپ با موفقیت ایجاد شد!');
            $('#backup-result').html('<p>فایل‌ها در پوشه <code>wp-content/exports/</code> ذخیره شدند.</p>');
        });
    }
});