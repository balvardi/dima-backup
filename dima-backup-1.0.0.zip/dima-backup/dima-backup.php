<?php
/*
Plugin Name: Dima Backup
Description: یک پلاگین ساده و امن برای بسته‌بندی سایت وردپرس جهت انتقال به سرور (با پشتیبانی از AJAX)
Version: 1.3
Author: You
*/

if (!defined('ABSPATH')) {
    exit;
}

define('DIMABACKUP_DIR', WP_CONTENT_DIR . '/exports/');
define('DIMABACKUP_URL', content_url('exports/'));

require_once plugin_dir_path(__FILE__) . 'includes/handlers.php';

// Admin menu
add_action('admin_menu', 'dima_backup_add_menu');
function dima_backup_add_menu() {
    add_management_page(
        'Dima Backup',
        'Dima Backup',
        'manage_options',
        'dima-backup',
        'dima_backup_render_page'
    );
}

// Enqueue scripts
add_action('admin_enqueue_scripts', 'dima_backup_enqueue_assets');
function dima_backup_enqueue_assets($hook) {
    if ($hook != 'tools_page_dima-backup') return;

    wp_enqueue_script('dima-ajax', plugins_url('assets/script.js', __FILE__), ['jquery'], null, true);
    wp_localize_script('dima-ajax', 'dimaAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('dima_backup_ajax_nonce')
    ]);
}

// Render page
function dima_backup_render_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('شما دسترسی لازم را ندارید.'));
    }
    ?>
    <div class="wrap">
        <h2>Dima Backup</h2>
        <form id="dima-backup-form">
            <?php wp_nonce_field('dima_backup_nonce', 'dima_backup_nonce'); ?>
            <table class="form-table">
                <tr><th scope="row">هاست دیتابیس</th><td><input type="text" name="db_host" value="localhost" class="regular-text"></td></tr>
                <tr><th scope="row">نام کاربری دیتابیس</th><td><input type="text" name="db_user" class="regular-text"></td></tr>
                <tr><th scope="row">رمز دیتابیس</th><td><input type="password" name="db_pass" class="regular-text"></td></tr>
                <tr><th scope="row">نام دیتابیس</th><td><input type="text" name="db_name" class="regular-text"></td></tr>
            </table>
            <p class="submit"><button type="submit" class="button button-primary">شروع بک‌آپ</button></p>
        </form>

        <div id="progress-container" style="display:none; margin-top:20px;">
            <progress id="backup-progress" value="0" max="100"></progress>
            <p id="backup-status">در حال آماده‌سازی...</p>
        </div>

        <div id="backup-result" style="margin-top:20px;"></div>
    </div>
    <?php
}