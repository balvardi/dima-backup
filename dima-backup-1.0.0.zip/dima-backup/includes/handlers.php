<?php
if (!defined('ABSPATH')) exit;

// AJAX handler for starting backup
add_action('wp_ajax_dimabackup_start', 'dimabackup_ajax_start');
function dimabackup_ajax_start() {
    check_ajax_referer('dima_backup_ajax_nonce', 'security');

    $data = $_POST['data'];
    $dir = DIMABACKUP_DIR;

    if (!is_dir($dir)) {
        if (!wp_mkdir_p($dir)) {
            wp_send_json_error(['message' => 'نمی‌تواند پوشه exports را ایجاد کند']);
        }
    }

    // Generate unique filename
    $unique_id = uniqid();
    $zip_filename = "backup_{$unique_id}.zip";

    // Save DB info + zip name
    $db_info = [
        'host' => sanitize_text_field($data['db_host']),
        'user' => sanitize_text_field($data['db_user']),
        'pass' => sanitize_text_field($data['db_pass']),
        'name' => sanitize_text_field($data['db_name']),
        'zip_file' => $zip_filename
    ];

    if (!file_put_contents("{$dir}db_info.json", json_encode($db_info))) {
        wp_send_json_error(['message' => 'ذخیره اطلاعات دیتابیس شکست خورد']);
    }

    update_option('dimabackup_status', 'start');

    wp_send_json_success(['step' => 'zip_files']);
}

// AJAX handler for zipping files
add_action('wp_ajax_dimabackup_zip', 'dimabackup_ajax_zip');
function dimabackup_ajax_zip() {
    check_ajax_referer('dima_backup_ajax_nonce', 'security');

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    WP_Filesystem();
    global $wp_filesystem;

    $dir = DIMABACKUP_DIR;

    // Load DB Info
    $db_info = json_decode(file_get_contents("{$dir}db_info.json"), true);
    $zip_file = "{$dir}{$db_info['zip_file']}";

    $zip = new ZipArchive();
    if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        $rootPath = realpath(ABSPATH);
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootPath),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($files as $file) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($rootPath) + 1);

            if (strpos($filePath, $dir) !== false || is_dir($filePath)) continue;
            $zip->addFile($filePath, $relativePath);
        }

        $zip->close();
    } else {
        wp_send_json_error(['message' => 'خطا در ایجاد فایل زیپ']);
    }

    update_option('dimabackup_status', 'zipped');
    wp_send_json_success(['step' => 'export_db']);
}

// AJAX handler for exporting database
add_action('wp_ajax_dimabackup_export_db', 'dimabackup_ajax_export_db');
function dimabackup_ajax_export_db() {
    check_ajax_referer('dima_backup_ajax_nonce', 'security');

    global $wpdb;

    $dir = DIMABACKUP_DIR;

    // Check tables
    $tables = $wpdb->get_col("SHOW TABLES");
    if (!$tables || empty($tables)) {
        wp_send_json_error(['message' => 'جدولی در دیتابیس یافت نشد']);
    }

    $output = '';

    foreach ($tables as $table) {
        $create = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
        if (!$create) {
            wp_send_json_error(['message' => "خطا در خواندن ساختار جدول {$table}"]);
        }

        $output .= "\n\n" . $create[1] . ";\n";

        $results = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
        if ($results) {
            foreach ($results as $row) {
                $keys = array_map(function($key) { return "`$key`"; }, array_keys($row));
                $values = array_map('esc_sql', array_values($row)); // ✅ استفاده از esc_sql
                $output .= "INSERT INTO `$table` (" . implode(', ', $keys) . ") VALUES ('" . implode("', '", $values) . "');\n";
            }
        }
    }

    // Save to file
    if (!file_put_contents("{$dir}database.sql", $output)) {
        wp_send_json_error(['message' => 'ذخیره فایل database.sql شکست خورد']);
    }

    update_option('dimabackup_status', 'db_exported');
    wp_send_json_success(['step' => 'generate_import']);
}

// AJAX handler for generating import.php
add_action('wp_ajax_dimabackup_generate_import', 'dimabackup_ajax_generate_import');
function dimabackup_ajax_generate_import() {
    check_ajax_referer('dima_backup_ajax_nonce', 'security');

    $dir = DIMABACKUP_DIR;

    if (!file_exists("{$dir}db_info.json")) {
        wp_send_json_error(['message' => 'فایل db_info.json وجود ندارد']);
    }

    $db_info = json_decode(file_get_contents("{$dir}db_info.json"), true);

    $import_code = <<<PHP
<?php
\$db_host = "{$db_info['host']}";
\$db_user = "{$db_info['user']}";
\$db_pass = "{$db_info['pass']}";
\$db_name = "{$db_info['name']}";
\$zipFile = "{$db_info['zip_file']}";

\$conn = new mysqli(\$db_host, \$db_user, \$db_pass, \$db_name);
if (\$conn->connect_error) die("Connection failed: " . \$conn->connect_error);

\$sql = file_get_contents("database.sql");
if (!mysqli_multi_query(\$conn, \$sql)) {
    echo "❌ Error importing database: " . \$conn->error;
} else {
    echo "✅ Database imported successfully.<br>";
    echo "Zip file: <code>{$zipFile}</code>";
}
?>
PHP;

    if (!file_put_contents("{$dir}import.php", $import_code)) {
        wp_send_json_error(['message' => 'ذخیره فایل import.php شکست خورد']);
    }

    update_option('dimabackup_status', 'completed');
    wp_send_json_success(['step' => 'done']);
}